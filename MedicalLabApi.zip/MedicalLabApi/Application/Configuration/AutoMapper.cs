﻿using AutoMapper;

namespace Application.Configuration;

public class AutoMapper : Profile
{
    public AutoMapper()
    {
    }
}